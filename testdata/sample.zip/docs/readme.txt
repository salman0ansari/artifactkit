ArtifactKit archive fixture
